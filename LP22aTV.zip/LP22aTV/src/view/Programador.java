package view;

import interfaces.EnergiaDAO;
import codigos.Energia;
import codigos.EnergiaView;

import interfaces.ConsumidorDAO;
import codigos.Consumidor;
import codigos.ConsumidorView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.util.List;
import java.util.Scanner;

public class Programador {
    static String URL = "jdbc:mysql://localhost:3306/lp22";
    static String USERNAME = "root";
    static String PASSWORD = "";
    static Scanner leia = new Scanner(System.in);

    public static void main(String[] args) throws SQLException {
        int opcao, opcaoConsumidor, opcaoEnergia;

        do {
            menu();
            opcao = Integer.parseInt(leia.nextLine());

            switch (opcao) {
                case 0:
                    break;
                case 1:
                    do {
                        menuConsumidor();
                        opcaoConsumidor = Integer.parseInt(leia.nextLine());

                        switch (opcaoConsumidor) {
                            case 0:
                                break;
                            case 1:
                                mostrarConsumidor();
                                break;
                            case 2:
                                cadastrarConsumidor();
                                break;
                            case 3:
                                editarConsumidor();
                                break;
                            case 4:
                                removerConsumidor();
                                break;
                            case 5:
                                buscarConsumidor();
                                break;
                            default:
                                System.out.println("Valor inserido não é válido.");
                                break;
                        }
                    } while (opcaoConsumidor != 0);

                    break;
                case 2:
                    do {
                        menuEnergia();
                        opcaoEnergia = Integer.parseInt(leia.nextLine());

                        switch (opcaoEnergia) {
                            case 0:
                                break;
                            case 1:
                                mostrarEnergia();
                                break;
                            case 2:
                                cadastrarEnergia();
                                break;
                            case 3:
                                editarEnergia();
                                break;
                            case 4:
                                removerEnergia();
                                break;
                            case 5:
                                buscarEnergia();
                                break;
                            default:
                                System.out.println("Valor inserido não é válido.");
                                break;
                        }
                    } while (opcaoEnergia != 0);
                    break;
                case 3:
                    mostrarTodos();
                    break;
                default:
                    System.out.println("Valor inserido não é válido.");
                    break;
            }
        } while (opcao != 0);
    }



private static void mostrarTodos() throws SQLException {
	Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	if( connection != null) {
    	System.out.println("\n----------------------------------------------------");
    	System.out.println("\tConectado ao Banco de Dados.");
    	System.out.println("----------------------------------------------------");
    }
	ConsumidorDAO consumidorDAO = new ConsumidorView(connection);
	EnergiaDAO energiaDAO = new EnergiaView(connection);

	// exibir funcionarios
	List<Consumidor> consumidor = consumidorDAO.listarConsumidor();
	System.out.println("\tConsumidores cadastrados:\n");
	System.out.println("------------------------");
	
	//laco de repeticao (foreach) percorrendo e mostrando os funcionarios cadastrados
	for (Consumidor consumidor1 : consumidor) {
	    System.out.println("ID: " + consumidor1.getConsumidorId());
	    System.out.println("Nome: " + consumidor1.getNome());
	    System.out.println("Cargo: " + consumidor1.getCargo());
	    System.out.println("Energia ID: " + consumidor1.getEnergiaId());
	    System.out.println("Endereco ID: " + consumidor1.getEndereco());
	    System.out.println("------------------------");
	}

	// exibir departamentos
	List<Energia> energia = energiaDAO.listarEnergia();
	System.out.println("\n\n\tSetores cadastrados:");
	System.out.println("------------------------");
	
	//laco de repeticao (foreach) percorrendo e mostrando os funcionarios cadastrados
	for (Energia energia1 : energia) {
	    System.out.println("ID: " + energia1.getId());
	    System.out.println("Nome: " + energia1.getNome());
	    System.out.println("Endereco: " + energia1.getEndereco());
	    System.out.println("Demanda: " + energia1.getDemanda());


	    System.out.println("------------------------");
	}

}
	
	   private static void menuEnergia() {
	        System.out.println("----- Menu Energia -----");
	        System.out.println("1. Mostrar Energia");
	        System.out.println("2. Cadastrar Energia");
	        System.out.println("3. Editar Energia");
	        System.out.println("4. Remover Energia");
	        System.out.println("5. Buscar Energia");
	        System.out.println("0. Voltar");
	        System.out.print("Opção: ");
	    }

	private static void buscarEnergia() {
		try {
			Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			EnergiaDAO energiaDAO = new EnergiaView(connection);
			
	        System.out.println("Informe o id do Energia: ");
	        int id = Integer.parseInt(leia.nextLine());
	        Energia  energia1 = energiaDAO.buscarEnergia(id);
	        if ( energia1 == null) {
	        	System.out.println("Energia nao encontrado.");
	        }else {
	        	System.out.println( energia1.getId() + " - " + energia1.getNome());
		        }
	        connection.close();
	    	} catch (SQLException e) {
	    	e.printStackTrace();

		}
		    	
    }


	private static void removerEnergia() {
		try {
	        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	        EnergiaDAO energiaDAO = new EnergiaView(connection);
	        mostrarEnergia();
	        System.out.println("Informe o id do Energia a ser excluido: ");
	        int num = Integer.parseInt(leia.nextLine());
	        
	        energiaDAO.excluirEnergia(num);
	        
	        connection.close();
	    	} catch (SQLException e) {
	    	e.printStackTrace();
	    	}
	}
	

	private static void editarEnergia() {
		try {
	        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	        EnergiaDAO energiaDAO = new EnergiaView(connection);
	        mostrarEnergia();
	        System.out.println("Informe o id do Energia: ");
	        int num = Integer.parseInt(leia.nextLine());
	        
	        System.out.println("Informe o novo nome do Energia: ");
	        String nome = leia.nextLine();
	        energiaDAO.atualizarEnergia(nome, num);
	        
	        connection.close();
	    	} catch (SQLException e) {
	    	e.printStackTrace();
	    	}
	}

   
	private static void cadastrarEnergia() {
		try {
	        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	        EnergiaDAO energiaDAO = new EnergiaView(connection);
			
	        System.out.println("Informe o nome do Energia: ");
	        String nome = leia.nextLine();
	        Energia energia1 = new Energia(nome);
	        energiaDAO.cadastrarEnergia(energia1);
	        
	        connection.close();
	    	} catch (SQLException e) {
	    	e.printStackTrace();
	    	}
	}

	private static void mostrarEnergia() {
		try {
	        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	        EnergiaDAO energiaDAO = new EnergiaView(connection);
	        System.out.println("Lista de Energia:");
	        List<Energia> energia = energiaDAO.listarEnergia();
	        for (Energia d : energia) {
	            System.out.println(d.getId() + " - " + d.getNome());
	        }
	        connection.close();
	    } catch (SQLException e) {
        e.printStackTrace();
}
	}

 
	
	
	private static void menuConsumidor() {
        System.out.println("----- Menu Consumidor -----");
        System.out.println("1. Mostrar Consumidor");
        System.out.println("2. Cadastrar Consumidor");
        System.out.println("3. Editar Consumidor");
        System.out.println("4. Remover Consumidor");
        System.out.println("5. Buscar Consumidor");
        System.out.println("0. Voltar");
        System.out.print("Opção: ");
    }
	
	
	
	
	
	
	

	private static void buscarConsumidor() {
		try {
	        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	        ConsumidorDAO consumidorDAO = new ConsumidorView(connection);
			System.out.print("Informe o id do Consumidor que deseja buscar: ");
	        int selecionou = Integer.parseInt(leia.nextLine());
	        Consumidor consumidor1 = consumidorDAO.buscarConsumidor(selecionou);
	        if (consumidor1 == null) {
	        	System.out.println("consumidor nao encontrado.");
	        }else {
	        	System.out.println(consumidor1.getNome() + " - " + consumidor1.getCargo() + " - " + consumidor1.getEnergiaId());
		        }
			connection.close();
	    } catch (SQLException e) {
        e.printStackTrace();
}
	}
    
    
    
    
    
    
    
    
    
    
    private static void removerConsumidor() {
		try {
	        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	        ConsumidorDAO funcionarioDAO = new ConsumidorView(connection);
	        mostrarConsumidor();
	        System.out.print("Informe o id do Funcionario que deseja apagar: ");
	        int selecionou = Integer.parseInt(leia.nextLine());
	        funcionarioDAO.excluirConsumidor(selecionou);
	        connection.close();
	    } catch (SQLException e) {
        e.printStackTrace();
}
    }







    
    
    
    
    
    private static void editarConsumidor() {
		try {
	        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	        ConsumidorDAO funcionarioDAO = new ConsumidorView(connection);
	        mostrarConsumidor();
	        System.out.print("Informe o id do Consumidor que deseja editar: ");
	        int selecionou = Integer.parseInt(leia.nextLine());
	        System.out.println("Informe o novo nome do Consumidor: ");
	        String nome = leia.nextLine();
	        System.out.println("Informe o novo nome do seu cargo: ");
	        String cargo = leia.nextLine();
	        mostrarEnergia();
	        System.out.println("Informe o novo numero da Energia: ");
	        int departamento = Integer.parseInt(leia.nextLine());
	        

	        Consumidor consumidor1 = new Consumidor(nome, cargo, departamento);
	        funcionarioDAO.atualizarConsumidor(consumidor1, selecionou);
	        connection.close();
	    } catch (SQLException e) {
        e.printStackTrace();
}
	}
   

    
    
    
    
    private static void cadastrarConsumidor() {
		try {
	        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	        ConsumidorDAO consumidorDAO = new ConsumidorView(connection);
	        System.out.println("Informe o nome do Consumidor: ");
	        String nome = leia.nextLine();
	        System.out.println("Informe o nome do seu cargo: ");
	        String cargo = leia.nextLine();
	        mostrarEnergia();
	        System.out.println("Informe o numerO de energia utilizada: ");
	        int energia = Integer.parseInt(leia.nextLine());
	        Consumidor consumidor1 = new Consumidor(nome, cargo, energia);
	        consumidorDAO.cadastrarConsumidor(consumidor1);
	        mostrarConsumidor();

	        connection.close();
	    	} catch (SQLException e) {
	    	e.printStackTrace();
	    	}
	}
	
	
	
	
	
    

        private static void mostrarConsumidor() {
            System.out.println("----- Mostrar Consumidor -----");

            Connection connection = null;
            try {
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                ConsumidorDAO consumidorDAO = new ConsumidorView(connection);

                List<Consumidor> consumidores = consumidorDAO.listarConsumidor();

                if (consumidores.isEmpty()) {
                    System.out.println("Não há consumidores cadastrados.");
                } else {
                    System.out.println("Consumidores cadastrados:\n");

                    for (Consumidor consumidor : consumidores) {
                        System.out.println("ID: " + consumidor.getConsumidorId());
                        System.out.println("Nome: " + consumidor.getNome());
                        System.out.println("Cargo: " + consumidor.getCargo());
                        System.out.println("Departamento ID: " + consumidor.getEnergiaId());
                        System.out.println("------------------------");
                    }
                }

            } catch (SQLException e) {
                System.out.println("Erro ao mostrar os consumidores: " + e.getMessage());

            } finally {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        System.out.println("Erro ao fechar a conexão com o banco de dados: " + e.getMessage());
                    }
                }
            }
        }
   

    

    private static void menu() {
        System.out.println("----- Menu Principal -----");
        System.out.println("1. Consumidor");
        System.out.println("2. Energia");
        System.out.println("3. Mostrar Todos");
        System.out.println("0. Sair");
        System.out.print("Opção: ");
    }

	
}