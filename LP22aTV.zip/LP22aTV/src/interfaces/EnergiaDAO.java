package interfaces;

import 	codigos.Energia;
import 	java.util.List;

public interface EnergiaDAO {
    void cadastrarEnergia(Energia energia);
    void excluirEnergia(int id);
    Energia buscarEnergia(int id);
    List<Energia> listarEnergia();
	void atualizarEnergia(String nome, int num);
}
