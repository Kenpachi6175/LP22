package interfaces;



import codigos.Consumidor;
import java.util.List;

public interface ConsumidorDAO {
    void cadastrarConsumidor(Consumidor consumidor);
    void excluirConsumidor(int id);
    Consumidor buscarConsumidor(int id);
    List<Consumidor> listarConsumidor();
	void atualizarConsumidor(Consumidor consumidor, int id);
	static void atualizarConsumidor(String nome, int num) {
		
		
	}
}
