package codigos;


public class Energia {
    private int id;
    private String nome;
    private String endereco;
    private int demanda;
    
    public Energia(){
		this.id  = 0;
		this.nome = "";
		this.endereco = "";
		this.demanda = 0;
	}
    
	public Energia(int energiaId, String nome2,String endereco, int demanda) {
		this.id  = energiaId;
		this.nome = nome2;
		this.endereco = endereco;
		this.demanda = demanda;
	}
	
	public Energia(String nome){
		this.nome = nome;
	}
	
	
	public Energia(int id2, String nome2, int demanda2, String endereco2) {
		
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	 public String getEndereco() {
	        return endereco;
	    }

	    public void setEndereco(String endereco) {
	        this.endereco = endereco;
	    }
	    public int getDemanda() {
	        return demanda;
	    }

	    public void setDemanda(int demanda) {
	        this.demanda = demanda;
	    }

	

		public void add(Energia energia1) {
			// TODO Auto-generated method stub
			
		}

}