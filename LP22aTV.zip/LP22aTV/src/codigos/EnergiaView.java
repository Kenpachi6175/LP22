package codigos;
import interfaces.EnergiaDAO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnergiaView implements EnergiaDAO {
private Connection connection;

public EnergiaView(Connection connection) {
    this.connection = connection;
}

@Override
public void cadastrarEnergia(Energia energia) {
    String sql = "INSERT INTO energia (id, nome) VALUES (?, ?)";

    try (PreparedStatement statement = connection.prepareStatement(sql)) {
        statement.setInt(1, energia.getId());
        statement.setString(2, energia.getNome());

        statement.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

@Override
public void atualizarEnergia(String nome, int num) {
    String sql = "UPDATE energia SET nome = ? WHERE id = ?";

    try (PreparedStatement statement = connection.prepareStatement(sql)) {
        statement.setString(1, nome);
        statement.setInt(2, num);

        statement.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

@Override
public void excluirEnergia(int id) {
    String sql = "DELETE FROM energia WHERE id = ?";

    try (PreparedStatement statement = connection.prepareStatement(sql)) {
        statement.setInt(1, id);

        statement.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

@Override
public Energia buscarEnergia(int id) {
    String sql = "SELECT * FROM energia WHERE id = ?";

    try (PreparedStatement statement = connection.prepareStatement(sql)) {
        statement.setInt(1, id);

        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            int energiaId = resultSet.getInt("id");
            String nome = resultSet.getString("nome");
            String endereco = resultSet.getString("endereco");
            int demanda = resultSet.getInt("demanda");
            
			return new Energia(energiaId, nome, demanda, endereco);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return null;
}

@Override
public List<Energia> listarEnergia() {
    List<Energia> energia = new ArrayList<>();

    String sql = "SELECT * FROM energia";

    try (Statement statement = connection.createStatement()) {
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String nome = resultSet.getString("nome");
            String endereco = resultSet.getString("endereco");
            int demanda = resultSet.getInt("demanda");

            Energia energia1 = new Energia(id, nome,demanda, endereco);
            energia1.add(energia1);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return energia;
}
}