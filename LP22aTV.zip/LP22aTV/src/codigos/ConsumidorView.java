package codigos;
import interfaces.ConsumidorDAO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConsumidorView implements ConsumidorDAO {
    private Connection connection;

    public ConsumidorView(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void cadastrarConsumidor(Consumidor consumidor) {
        String sql = "INSERT INTO consumidor (nome, cargo, departamentoId) VALUES ( ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, consumidor.getNome());
            statement.setString(2, consumidor.getCargo());
            statement.setInt(3, consumidor.getConsumidorId());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizarConsumidor(Consumidor consumidor, int id) {
        String sql = "UPDATE consumidor SET nome = ?, cargo = ?, energiaId = ? WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, consumidor.getNome());
            statement.setString(2, consumidor.getCargo());
            statement.setInt(3, consumidor.getEnergiaId());
            statement.setInt(4, id);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void excluirConsumidor(int id) {
        String sql = "DELETE FROM consumidor WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Consumidor buscarConsumidor(int id) {
        String sql = "SELECT * FROM consumidor WHERE id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
            	int id1 = resultSet.getInt("id");
                String nome = resultSet.getString("nome");
                String cargo = resultSet.getString("cargo");
                int energiaId = resultSet.getInt("energiaId");

                return new Consumidor(id1, nome, cargo, energiaId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public List<Consumidor> listarConsumidor() {
        List<Consumidor> consumidor = new ArrayList<>();

        String sql = "SELECT * FROM consumidor";

        try (Statement statement = connection.createStatement()) {
        	
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
            	int id = resultSet.getInt("id");
                String nome = resultSet.getString("nome");
                String cargo = resultSet.getString("cargo");
                int energiaId = resultSet.getInt("energiaId");
                String endereco = resultSet.getString("endereco");

                Consumidor consumidor1 = new Consumidor(id, nome, cargo, energiaId, endereco);
                consumidor1.add(consumidor1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return consumidor;
    }



	
}
