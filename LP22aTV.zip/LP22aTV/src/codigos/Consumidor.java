

package codigos;

public class Consumidor {
	private int consumidorId;
    private String nome;
    private String cargo;
    private int energiaId;
    private String endereco;
    
 
    public Consumidor( String nome2, String cargo2, int departamentoId2) {
		this.nome = nome2;
		this.cargo = cargo2;
		this.energiaId  = departamentoId2;
	}
    
   
	public Consumidor(int id, String nome2, String cargo2, int departamentoId2) {
		this.consumidorId = id;
		this.nome = nome2;
		this.cargo = cargo2;
		this.energiaId  = departamentoId2;
	}
	
	
	public Consumidor() {
		this.setConsumidorId(0);
		this.nome = "";
		this.cargo = "";
		this.energiaId  = 0;
	}
	public Consumidor(int id, String nome2, String cargo2, int energiaId2, String endereco2) {
		
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	public int getConsumidorId() {
		return consumidorId;
	}
	public void setConsumidorId(int consumidorId) {
		this.consumidorId = consumidorId;
	}

	public int getEnergiaId() {
		return energiaId;
	}

	public void setEnergiaId(int energiaId) {
		this.energiaId = energiaId;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public void add(Consumidor consumidor) {
		
		
	}

	public String getId() {
		
		return null;
	}

   
}
